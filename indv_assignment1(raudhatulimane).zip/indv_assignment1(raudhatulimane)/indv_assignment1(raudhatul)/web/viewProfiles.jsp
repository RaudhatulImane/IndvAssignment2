<%-- 
    Document   : viewProfiles
    Created on : Jun 20, 2026, 1:23:18 PM
    Author     : user
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@page import="java.util.ArrayList"%>
<%@page import="model.ProfileBean"%>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>All Student Profiles</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
          rel="stylesheet">

    <style>
        body{
            background-color:#ffe6ee;
        }

        .main-card{
            background:white;
            border-radius:12px;
            padding:30px;
            margin-top:40px;
            box-shadow:0 4px 15px rgba(0,0,0,0.1);
        }

        .title{
            color:#d96c93;
            font-weight:bold;
            text-align:center;
            margin-bottom:25px;
        }

        .table th{
            background-color:#d96c93;
            color:white;
        }

        .btn-custom{
            background-color:#d96c93;
            color:white;
            border:none;
        }

        .btn-custom:hover{
            background-color:#c45880;
            color:white;
        }
    </style>
</head>

<body>

<div class="container">

    <div class="main-card">

        <h2 class="title">
            <i class="fa-solid fa-users"></i>
            All Student Profiles
        </h2>

        <form action="SearchProfileServlet" method="get" class="row mb-4">

    <div class="col-md-4">
        <input type="text"
               name="studentID"
               class="form-control"
               placeholder="Search by Student ID">
    </div>

    <div class="col-md-4">
        <input type="text"
               name="name"
               class="form-control"
               placeholder="Search by Name">
    </div>

    <div class="col-md-4">
        <button type="submit"
                class="btn btn-custom">
            <i class="fa-solid fa-magnifying-glass"></i>
            Search
        </button>

        <a href="ViewProfilesServlet"
           class="btn btn-secondary">
            Show All
        </a>
    </div>

</form>
        
        <table class="table table-bordered table-striped">

            <thead>
                <tr>
                    <th>Student ID</th>
                    <th>Name</th>
                    <th>Programme</th>
                    <th>Email</th>
                    <th>Hobbies</th>
                    <th>Introduction</th>
                     <th>Action</th>
                </tr>
            </thead>

            <tbody>

            <%
                ArrayList<ProfileBean> profileList =
                    (ArrayList<ProfileBean>)request.getAttribute("profileList");

                if(profileList != null){

                    for(ProfileBean profile : profileList){
            %>

                <tr>
    <td><%= profile.getStudentID() %></td>
    <td><%= profile.getName() %></td>
    <td><%= profile.getProgramme() %></td>
    <td><%= profile.getEmail() %></td>
    <td><%= profile.getHobbies() %></td>
    <td><%= profile.getIntroduction() %></td>

    <td>
        <a href="editProfile.jsp?studentID=<%=profile.getStudentID()%>&name=<%=profile.getName()%>&programme=<%=profile.getProgramme()%>&email=<%=profile.getEmail()%>&hobbies=<%=profile.getHobbies()%>&introduction=<%=profile.getIntroduction()%>"
           class="btn btn-warning btn-sm">
            <i class="fa-solid fa-pen-to-square"></i>
            Edit
        </a>
    </td>
</tr>

            <%
                    }
                }
            %>

            </tbody>

        </table>

        <div class="text-center mt-3">

            <a href="index.html" class="btn btn-custom">
                Back to Home
            </a>

        </div>

    </div>

</div>

</body>
</html>