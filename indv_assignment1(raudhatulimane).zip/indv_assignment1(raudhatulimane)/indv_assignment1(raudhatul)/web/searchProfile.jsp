<%@page contentType="text/html" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
    <title>Search Profile</title>
</head>
<body>

<h2>Search Student Profile</h2>

<form action="SearchProfileServlet" method="get">

    Student ID:
    <input type="text" name="studentID">
    <br><br>

    OR Name:
    <input type="text" name="name">
    <br><br>

    <input type="submit" value="Search">

</form>

</body>
</html>