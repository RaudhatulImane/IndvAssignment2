
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Profile Result</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>
        body {
            background-color: #ffe6ee;
        }

        .profile-display-card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            margin-top: 50px;
            padding: 0;
            overflow: hidden;
        }

        .profile-header {
            background: linear-gradient(135deg, #d96c93, #c45880);
            color: white;
            padding: 30px;
            text-align: center;
        }

        .profile-header i {
            font-size: 40px;
        }

        .profile-body {
            padding: 30px;
        }

        .info-row {
            padding: 12px 0;
            border-bottom: 1px solid #eee;
        }

        .info-row:last-child {
            border-bottom: none;
        }

        .label-title {
            font-weight: 600;
            color: #b04f74;
        }

        .text-secondary {
            color: #555 !important;
        }
    </style>
</head>
<body>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6 profile-display-card">

                <div class="profile-header">

                    <div class="d-flex justify-content-center align-items-center gap-2">
                        <i class="fa-solid fa-graduation-cap"></i>
                        <h2 class="m-0">Student Information</h2>
                    </div>

                    <p class="lead mt-2 mb-0">
                        Thank you, ${profile.name}!
                    </p>

                </div>

                <div class="profile-body">

                    <div class="row info-row">
                        <i class="fa-solid fa-user"></i> 
                        <div class="col-sm-4 label-title">Full Name:</div>
                        <div class="col-sm-8 text-secondary">
                            ${profile.name}
                        </div>
                    </div>

                    <div class="row info-row">
                        <i class="fa-solid fa-id-card"></i> 
                        <div class="col-sm-4 label-title">Student ID:</div>
                        <div class="col-sm-8 text-secondary">
                            ${profile.studentID}
                        </div>
                    </div>

                    <div class="row info-row">
                        <i class="fa-solid fa-book"></i> 
                        <div class="col-sm-4 label-title">Programme:</div>
                        <div class="col-sm-8 text-secondary">
                            ${profile.programme}
                        </div>
                    </div>

                    <div class="row info-row">
                        <i class="fa-solid fa-envelope"></i> 
                        <div class="col-sm-4 label-title">Email:</div>
                        <div class="col-sm-8 text-secondary">
                            ${profile.email}
                        </div>
                    </div>

                    <div class="row info-row">
                        <i class="fa-solid fa-heart"></i> 
                        <div class="col-sm-4 label-title">Hobbies:</div>
                        <div class="col-sm-8 text-secondary">
                            ${profile.hobbies}
                        </div>
                    </div>

                    <div class="row info-row">
                        
                        <div class="col-sm-4 label-title">Introduction:</div>
                        <div class="col-sm-8 text-secondary">
                            ${profile.introduction}
                        </div>
                    </div>

                    <div class="mt-4 text-center">
                        <a href="index.html" class="btn btn-primary">
                            Back to Home
                        </a>

                        <a href="ViewProfilesServlet" class="btn btn-success">
                            View All Profiles
                        </a>
                    </div>

                </div>

            </div>
        </div>
    </div>

</body>
</html>
