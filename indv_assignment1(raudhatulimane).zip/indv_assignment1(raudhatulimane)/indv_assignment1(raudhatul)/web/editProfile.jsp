<%@page contentType="text/html" pageEncoding="UTF-8"%>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Profile</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
          rel="stylesheet">

    <style>
        body{
            background-color:#ffe6ee;
        }

        .edit-card{
            background:white;
            padding:35px;
            border-radius:12px;
            box-shadow:0 4px 15px rgba(0,0,0,0.1);
            margin-top:40px;
        }

        h2{
            color:#d96c93;
            font-weight:bold;
            text-align:center;
            margin-bottom:25px;
        }

        label{
            font-weight:600;
            color:#b04f74;
        }

        .form-control:focus{
            border-color:#d96c93;
            box-shadow:0 0 0 0.2rem rgba(217,108,147,0.25);
        }

        .btn-success{
            background-color:#d96c93;
            border-color:#d96c93;
        }

        .btn-success:hover{
            background-color:#c45880;
            border-color:#c45880;
        }
    </style>
</head>

<body>

<div class="container mt-5">

    <div class="row justify-content-center">
        <div class="col-md-8">

            <div class="edit-card">

                <h2>Edit Student Profile</h2>

                <form action="UpdateProfileServlet"
                      method="post">

                    <div class="mb-3">
                        <label>Student ID</label>
                        <input type="text"
                               class="form-control"
                               name="studentID"
                               value="<%=request.getParameter("studentID")%>"
                               readonly>
                    </div>

                    <div class="mb-3">
                        <label>Name</label>
                        <input type="text"
                               class="form-control"
                               name="name"
                               value="<%=request.getParameter("name")%>">
                    </div>

                    <div class="mb-3">
                        <label>Programme</label>
                        <input type="text"
                               class="form-control"
                               name="programme"
                               value="<%=request.getParameter("programme")%>">
                    </div>

                    <div class="mb-3">
                        <label>Email</label>
                        <input type="email"
                               class="form-control"
                               name="email"
                               value="<%=request.getParameter("email")%>">
                    </div>

                    <div class="mb-3">
                        <label>Hobbies</label>
                        <input type="text"
                               class="form-control"
                               name="hobbies"
                               value="<%=request.getParameter("hobbies")%>">
                    </div>

                    <div class="mb-3">
                        <label>Introduction</label>
                        <textarea class="form-control"
                                  name="introduction"
                                  rows="4"><%=request.getParameter("introduction")%></textarea>
                    </div>

                    <button type="submit"
                            class="btn btn-success">
                        Update
                    </button>

                    <a href="ViewProfilesServlet"
                       class="btn btn-secondary">
                        Cancel
                    </a>

                </form>

            </div>

        </div>
    </div>

</div>

</body>
</html>