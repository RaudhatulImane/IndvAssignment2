import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class UpdateProfileServlet extends HttpServlet {

    @Override
    protected void doPost(
            HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        String studentID =
                request.getParameter("studentID");

        String name =
                request.getParameter("name");

        String programme =
                request.getParameter("programme");

        String email =
                request.getParameter("email");

        String hobbies =
                request.getParameter("hobbies");

        String introduction =
                request.getParameter("introduction");

        try {

            Class.forName(
                    "org.apache.derby.jdbc.ClientDriver");

            Connection conn =
                    DriverManager.getConnection(
                            "jdbc:derby://localhost:1527/StudentProfileDB",
                            "app",
                            "123");

            String sql =
                "UPDATE APP.PROFILE "
                + "SET NAME=?, "
                + "PROGRAMME=?, "
                + "EMAIL=?, "
                + "HOBBIES=?, "
                + "INTRODUCTION=? "
                + "WHERE STUDENTID=?";

            PreparedStatement ps =
                    conn.prepareStatement(sql);

            ps.setString(1, name);
            ps.setString(2, programme);
            ps.setString(3, email);
            ps.setString(4, hobbies);
            ps.setString(5, introduction);
            ps.setString(6, studentID);

            ps.executeUpdate();

            ps.close();
            conn.close();

        } catch(Exception e) {
            e.printStackTrace();
        }

        response.sendRedirect(
                "ViewProfilesServlet");
    }
}