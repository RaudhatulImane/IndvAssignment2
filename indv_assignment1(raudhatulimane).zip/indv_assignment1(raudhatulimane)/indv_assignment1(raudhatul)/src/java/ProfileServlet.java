
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.ProfileBean;

public class ProfileServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        response.sendRedirect("collectInfo.html");
    }

    @Override
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");

        
        String name = request.getParameter("name");
        String studentId = request.getParameter("studentId");
        String program = request.getParameter("program");
        String email = request.getParameter("email");
        String hobbies = request.getParameter("hobbies");
        String introduction = request.getParameter("introduction");

        
        ProfileBean profile = new ProfileBean();

        profile.setStudentID(studentId);
        profile.setName(name);
        profile.setProgramme(program);
        profile.setEmail(email);
        profile.setHobbies(hobbies);
        profile.setIntroduction(introduction);

        
        try {

    Class.forName("org.apache.derby.jdbc.ClientDriver");

    Connection conn = DriverManager.getConnection(
            "jdbc:derby://localhost:1527/StudentProfileDB",
            "app",
            "123"
    );

    String sql =
            "INSERT INTO APP.PROFILE "
            + "(STUDENTID, NAME, PROGRAMME, EMAIL, HOBBIES, INTRODUCTION) "
            + "VALUES (?, ?, ?, ?, ?, ?)";

    PreparedStatement ps = conn.prepareStatement(sql);

    ps.setString(1, studentId);
    ps.setString(2, name);
    ps.setString(3, program);
    ps.setString(4, email);
    ps.setString(5, hobbies);
    ps.setString(6, introduction);

    int rows = ps.executeUpdate();

    ps.close();
    conn.close();

} catch (Exception e) {
    e.printStackTrace();

}

        
        request.setAttribute("profile", profile);

        RequestDispatcher dispatcher =
                request.getRequestDispatcher("profile.jsp");

        dispatcher.forward(request, response);
    }
}
