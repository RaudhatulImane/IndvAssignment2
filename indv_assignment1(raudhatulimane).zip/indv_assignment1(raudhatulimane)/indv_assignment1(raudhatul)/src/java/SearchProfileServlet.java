import model.ProfileBean;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SearchProfileServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        ArrayList<ProfileBean> profileList =
                new ArrayList<ProfileBean>();

        String studentID =
                request.getParameter("studentID");

        String name =
                request.getParameter("name");

        try {

            Class.forName(
                    "org.apache.derby.jdbc.ClientDriver");

            Connection conn =
                    DriverManager.getConnection(
                            "jdbc:derby://localhost:1527/StudentProfileDB",
                            "app",
                            "123");

            String sql;

            if(studentID != null &&
                    !studentID.trim().equals("")) {

                sql =
                    "SELECT * FROM APP.PROFILE "
                    + "WHERE STUDENTID=?";

                PreparedStatement ps =
                        conn.prepareStatement(sql);

                ps.setString(1, studentID);

                ResultSet rs =
                        ps.executeQuery();

                while(rs.next()) {

                    ProfileBean profile =
                            new ProfileBean();

                    profile.setStudentID(
                            rs.getString("STUDENTID"));

                    profile.setName(
                            rs.getString("NAME"));

                    profile.setProgramme(
                            rs.getString("PROGRAMME"));

                    profile.setEmail(
                            rs.getString("EMAIL"));

                    profile.setHobbies(
                            rs.getString("HOBBIES"));

                    profile.setIntroduction(
                            rs.getString("INTRODUCTION"));

                    profileList.add(profile);
                }

                rs.close();
                ps.close();

            } else {

                sql =
                    "SELECT * FROM APP.PROFILE "
                    + "WHERE NAME LIKE ?";

                PreparedStatement ps =
                        conn.prepareStatement(sql);

                ps.setString(1,
                        "%" + name + "%");

                ResultSet rs =
                        ps.executeQuery();

                while(rs.next()) {

                    ProfileBean profile =
                            new ProfileBean();

                    profile.setStudentID(
                            rs.getString("STUDENTID"));

                    profile.setName(
                            rs.getString("NAME"));

                    profile.setProgramme(
                            rs.getString("PROGRAMME"));

                    profile.setEmail(
                            rs.getString("EMAIL"));

                    profile.setHobbies(
                            rs.getString("HOBBIES"));

                    profile.setIntroduction(
                            rs.getString("INTRODUCTION"));

                    profileList.add(profile);
                }

                rs.close();
                ps.close();
            }

            conn.close();

        } catch(Exception e) {
            e.printStackTrace();
        }

        request.setAttribute(
                "profileList",
                profileList);

        RequestDispatcher dispatcher =
                request.getRequestDispatcher(
                        "viewProfiles.jsp");

        dispatcher.forward(
                request,
                response);
    }
}